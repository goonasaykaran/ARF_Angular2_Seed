setTimeout(() =>console.log("i win!"), 3000);
