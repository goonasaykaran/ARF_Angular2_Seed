require('../../../modules/es6.string.anchor');
module.exports = require('../../../modules/_entry-virtual')('String').anchor;