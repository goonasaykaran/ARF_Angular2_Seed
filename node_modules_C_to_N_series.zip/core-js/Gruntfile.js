require('LiveScript');
module.exports = require('./build/Gruntfile');