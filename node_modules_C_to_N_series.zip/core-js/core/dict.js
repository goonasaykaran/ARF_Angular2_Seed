require('../modules/core.dict');
module.exports = require('../modules/_core').Dict;