import { Component } from '@angular/core';

export class Hero {
  id: number;
  name: string;
}

@Component({
  selector: 'my-app',
  styleUrls: ['./app.component.css'],
  templateUrl: './app.component.html'
})
export class AppComponent {
  private _opened: boolean = false;
  private _modeNum: number = 0;

  private _MODES: 'push';
  
  private _toggleSidebar() {
    this._opened = !this._opened;
  }
}
