export declare function findFormatter(name: string | Function, formattersDirectory?: string): any;
