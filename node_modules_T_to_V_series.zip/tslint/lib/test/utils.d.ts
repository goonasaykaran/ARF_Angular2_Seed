export declare function replicateStr(str: string, numTimes: number): string;
