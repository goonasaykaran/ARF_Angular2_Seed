var chars = require('./chars');

module.exports = function reverse(str) {
  return chars(str).reverse().join('');
};
