# ES6 Promise shim

Promise.js in this dir contains a complete ES6 Promise shim built on when.js that adds a global `Promise` in browser, AMD, Node, and other CommonJS environments.

[Go to the full documentation](../docs/es6-promise-shim.md)