# Promise monitoring and debugging

This dir contains experimental new promise monitoring and debugging utilities for when.js.  See [the docs](../docs/api.md#debugging-promises).
