"use strict";

var _dec, _class;

var HelloComponent = (_dec = Component({ selector: "hello" }), _dec(_class = function HelloComponent(foo, bar) {
  babelHelpers.classCallCheck(this, HelloComponent);
}) || _class);
Yes({ key: "value" })(HelloComponent, null, 0);
No()(HelloComponent, null, 0);
Reflect.defineMetadata("design:paramtypes", [Foo, Bar], HelloComponent);
