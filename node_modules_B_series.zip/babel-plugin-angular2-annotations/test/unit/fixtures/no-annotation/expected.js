"use strict";

var HelloComponent = function HelloComponent(foo, bar) {
  babelHelpers.classCallCheck(this, HelloComponent);
};
