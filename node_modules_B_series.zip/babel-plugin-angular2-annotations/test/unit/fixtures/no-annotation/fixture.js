class HelloComponent {
  constructor(foo, bar) {
  }
}
