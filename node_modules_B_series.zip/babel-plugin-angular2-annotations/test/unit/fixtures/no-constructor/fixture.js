@Component({ selector: "hello" })
class HelloComponent {
}
