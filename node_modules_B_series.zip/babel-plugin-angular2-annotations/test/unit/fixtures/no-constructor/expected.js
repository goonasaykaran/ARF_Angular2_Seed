"use strict";

var _dec, _class;

var HelloComponent = (_dec = Component({ selector: "hello" }), _dec(_class = function HelloComponent() {
  babelHelpers.classCallCheck(this, HelloComponent);
}) || _class);
