"use strict";

var _dec, _class;

var HelloComponent = (_dec = Component({ selector: "hello" }), _dec(_class = function HelloComponent(str, num, bool, voi, obj, objProps, func, routerLinks) {
  babelHelpers.classCallCheck(this, HelloComponent);
}) || _class);
Query(RouterLink)(HelloComponent, null, 7);
Reflect.defineMetadata("design:paramtypes", [String, Number, Boolean, void 0, Object, Object, Function, QueryList], HelloComponent);
