"use strict";
var Observable_1 = require('../../Observable');
var GenerateObservable_1 = require('../../observable/GenerateObservable');
Observable_1.Observable.generate = GenerateObservable_1.GenerateObservable.create;
//# sourceMappingURL=generate.js.map