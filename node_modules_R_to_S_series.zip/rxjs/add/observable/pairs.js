"use strict";
var Observable_1 = require('../../Observable');
var pairs_1 = require('../../observable/pairs');
Observable_1.Observable.pairs = pairs_1.pairs;
//# sourceMappingURL=pairs.js.map