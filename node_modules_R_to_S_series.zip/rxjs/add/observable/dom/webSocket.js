"use strict";
var Observable_1 = require('../../../Observable');
var webSocket_1 = require('../../../observable/dom/webSocket');
Observable_1.Observable.webSocket = webSocket_1.webSocket;
//# sourceMappingURL=webSocket.js.map