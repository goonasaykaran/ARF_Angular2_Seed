## History

### 1.0.1 - 25th Sep 2016

- [b78606d](https://github.com/darsain/remove-trailing-separator/commit/af90b4e153a4527894741af6c7005acaeb78606d) Remove backslash only on win32 systems

### 1.0.0 - 24th Sep 2016

Initial release.